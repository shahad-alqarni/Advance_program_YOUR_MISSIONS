/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advance_program;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene; 
import javafx.stage.Stage;

/**
 *
 * @author Sh000
 */
public class Advance_program extends Application {

     @Override
    public void start(Stage primaryStage) throws IOException {
   
        Parent root=FXMLLoader.load(getClass().getResource(("Animation1.fxml")));
        Scene scene=new Scene(root);
     
 
        primaryStage.setTitle("your Mission");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
          
       launch(args);
    }
    
}
